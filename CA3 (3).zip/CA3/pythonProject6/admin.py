from flask import Flask, render_template, session, redirect, url_for, request, Blueprint
import models
from app import app
admin_page = Blueprint('admin_page', __name__, template_folder='templates/admin')


@admin_page.route("/admin/")
def admin():
    if not logged_in():
        return redirect(url_for('login', next='/admin/'))

    return render_template('index.html', title="ADMIN", information="Here you can administer products, services, etc. Click on what you would like to do")

@admin_page.route("/admin/create-all-tables/")
def create_all_tables():

    try:
        with app.app_context():
           models.db.create_all()
    except Exception as e:
        return 'Tables not created. Reason: {}'.format(e.__cause__)

    return 'Tables successfully created!'


@admin_page.route("/admin/products/")
def product():
    if not logged_in():
        return redirect(url_for('login', next='/admin/products/'))

    with app.app_context():
        products = models.Product.query.all()


    information = request.args.get('information', 'Here you can administer products')

    css = request.args.get('css', 'normal')
    return render_template('products.html', title="ADMINISTER PRODUCTS", information=information, css=css, products= products)



@admin_page.route("/admin/products/process-product-add/", methods=['POST','GET'])
def process_product_add():
    if not logged_in():
        return redirect(url_for('login', next='/admin/products/'))

    if request.method != 'POST':

        error = 'Please use the form to add new products'
        return render_template('products.html', title="ADMINISTER PRODUCTS", information=error, css="error")

    name = request.form['name']
    code = request.form['code']
    description = request.form['description']
    price_per_unit = request.form['price_per_unit']
    product_inception_date = request.form['product_inception_date']

    try:
        with app.app_context():
            product = models.Product(name=name, code=code, description=description, price_per_unit=price_per_unit,product_inception_date=product_inception_date)
            models.db.session.add(product)
            models.db.session.commit()

    except Exception as e:
        error = 'Could not submit. The error message is {}'.format(e.__cause__)
        return render_template('products.html', title="ADMINISTER PRODUCTS", information=error, css="error")


    return redirect(url_for('admin_page.product', information="Add successful", css="success"))

@admin_page.route("/admin/products/edit/<int:id>/", methods=['POST','GET'])
def products_edit(id):
     with app.app_context():
         products = models.Product.query.filter_by(id=id).first()

     return render_template('product-edit.html', product=products)


@admin_page.route("/admin/products/process-product-edit/<int:id>/", methods=['POST', 'GET'])
def process_product_edit(id):
    if not logged_in():
        return redirect(url_for('login', next='/admin/products/'))

    if request.method != 'POST':

        error = 'Please use the form to edit product'
        return render_template('products.html', title="ADMINISTER PRODUCTS", information=error, css="error")

    name = request.form['name']
    code = request.form['code']
    description = request.form['description']
    price_per_unit = request.form['price_per_unit']
    product_inception_date = request.form['product_inception_date']

    try:
        with app.app_context():
            product = models.Product.query.filter_by(id=id).first()

            product.name = name
            product.code = code
            product.description = description
            product.price_per_unit = price_per_unit
            product.product_inception_date = product_inception_date

            models.db.session.commit()

    except Exception as e:
        error = 'Could not update product. The error message is {}'.format(e.__cause__)
        return redirect(url_for('admin_page.product', information="Update not successful", css="error"))

    return redirect(url_for('admin_page.product', information="Update successful", css="success"))

@admin_page.route("/admin/products/delete/<int:id>/", methods=['POST', 'GET'])
def product_delete(id):
    if not logged_in():
        return redirect(url_for('login', next='/admin/products/'))

    try:
     with app.app_context():

        product = models.Product.query.filter_by(id=id).first()
        models.db.session.delete(product)
        models.db.session.commit()

    except Exception as e:
        error = 'Could not delete product. The error message is {}'.format(e.__cause__)
        return redirect(url_for('admin_page.product', information="Delete not successful", css="error"))

    return redirect(url_for('admin_page.product', information="Delete successful", css="success"))





@admin_page.route("/admin/order/")
def order():
    if not logged_in():
        return redirect(url_for('login', next='/admin/order/'))

    with app.app_context():
        orders = models.Order.query.all()


    information = request.args.get('information', 'Here you can administer order')

    css = request.args.get('css', 'normal')
    return render_template('order.html', title="ADMINISTER ORDER", information=information, css=css, orders=orders)



@admin_page.route("/admin/order/process-order-add/", methods=['POST','GET'])
def process_order_add():
    if not logged_in():
        return redirect(url_for('login', next='/admin/order/'))

    if request.method != 'POST':

        error = 'Please use the form to add new order'
        return render_template('order.html', title="ADMINISTER ORDER", information=error, css="error")

    order_name = request.form['name']
    quantity = request.form['quantity']
    customer_id = request.form['customer id']


    try:
        with app.app_context():
            order = models.Order(order_name=order_name, quantity=quantity, customer_id=customer_id)
            models.db.session.add(order)
            models.db.session.commit()

    except Exception as e:
        error = 'Could not submit. The error message is {}'.format(e.__cause__)
        return render_template('order.html', title="ADMINISTER ORDER", information=error, css="error")


    return redirect(url_for('admin_page.order', information="Add successful", css="success"))

@admin_page.route("/admin/order/edit/<int:order_id>/", methods=['POST','GET'])
def order_edit(order_id):
     with app.app_context():
         order = models.Order.query.filter_by(order_id=order_id).first()

     return render_template('order-edit.html', order=order)


@admin_page.route("/admin/order/process-order-edit/<int:order_id>/", methods=['POST', 'GET'])
def process_order_edit(order_id):
    if not logged_in():
        return redirect(url_for('login', next='/admin/order/'))

    if request.method != 'POST':

        error = 'Please use the form to edit order'
        return render_template('order.html', title="ADMINISTER ORDER", information=error, css="error")

    order_name = request.form['name']
    quantity = request.form['quantity']
    customer_id = request.form['customer_id']


    try:
        with app.app_context():
            order = models.Order.query.filter_by(order_id=order_id).first()
            order.order_name = order_name
            order.quantity = quantity
            order.customer_id = customer_id

            models.db.session.commit()

    except Exception as e:
        error = 'Could not update order. The error message is {}'.format(e.__cause__)
        return redirect(url_for('admin_page.order', information="Update not successful", css="error"))

    return redirect(url_for('admin_page.order', information="Update successful", css="success"))

@admin_page.route("/admin/order/delete/<int:order_id>/", methods=['POST', 'GET'])
def order_delete(order_id):
    if not logged_in():
        return redirect(url_for('login', next='/admin/order/'))

    try:
     with app.app_context():

        order = models.Order.query.filter_by(order_id=order_id).first()
        models.db.session.delete(order)
        models.db.session.commit()

    except Exception as e:
        error = 'Could not delete order. The error message is {}'.format(e.__cause__)
        return redirect(url_for('admin_page.order', information="Delete not successful", css="error"))


    return redirect(url_for('admin_page.order', information="Delete successful", css="success"))




@admin_page.route("/admin/customer/")
def customer():
    if not logged_in():
        return redirect(url_for('login', next='/admin/customer/'))

    with app.app_context():
        customers = models.Customer.query.all()


    information = request.args.get('information', 'Here you can administer customer')

    css = request.args.get('css', 'normal')
    return render_template('customer.html', title="ADMINISTER CUSTOMER", information=information, css=css, customers=customers)



@admin_page.route("/admin/customer/process-customer-add/", methods=['POST','GET'])
def process_customer_add():
    if not logged_in():
        return redirect(url_for('login', next='/admin/customer/'))

    if request.method != 'POST':

        error = 'Please use the form to add new customer'
        return render_template('customer.html', title="ADMINISTER CUSTOMER", information=error, css="error")

    firstname = request.form['firstname']
    lastname = request.form['lastname']
    email = request.form['email']


    try:
        with app.app_context():
            customers = models.Customer(firstname=firstname, lastname=lastname, email=email)
            models.db.session.add(customers)
            models.db.session.commit()

    except Exception as e:
        error = 'Could not submit. The error message is {}'.format(e.__cause__)
        return render_template('customer.html', title="ADMINISTER CUSTOMER", information=error, css="error")


    return redirect(url_for('admin_page.customer', information="Add successful", css="success"))

@admin_page.route("/admin/customer/edit/<int:id>/", methods=['POST','GET'])
def customer_edit(id):
     with app.app_context():
         Customer = models.Customer.query.filter_by(id=id).first()

     return render_template('customer-edit.html', Customer=Customer)


@admin_page.route("/admin/customer/process-customer-edit/<int:id>/", methods=['POST', 'GET'])
def process_customer_edit(id):
    if not logged_in():
        return redirect(url_for('login', next='/admin/customer/'))

    if request.method != 'POST':
        error = 'Please use the form to edit customer'
        return render_template('customer.html', title="ADMINISTER CUSTOMER", information=error, css="error")

    firstname = request.form['firstname']
    lastname = request.form['lastname']
    email = request.form['email']


    try:
        with app.app_context():
            customer = models.Customer.query.filter_by(id=id).first()
            customer.firstname = firstname
            customer.lastname = lastname
            customer.email = email

            models.db.session.commit()

    except Exception as e:
        error = 'Could not update order. The error message is {}'.format(e.__cause__)
        return redirect(url_for('admin_page.customer', information="Update not successful", css="error"))

    return redirect(url_for('admin_page.customer', information="Update successful", css="success"))

@admin_page.route("/admin/customer/delete/<int:id>/", methods=['POST', 'GET'])
def customer_delete(id):
    if not logged_in():
        return redirect(url_for('login', next='/admin/customer/'))

    try:
     with app.app_context():

        customers = models.Customer.query.filter_by(id=id).first()
        models.db.session.delete(customers)
        models.db.session.commit()

    except Exception as e:
        error = 'Could not delete order. The error message is {}'.format(e.__cause__)
        return redirect(url_for('admin_page.customer', information="Delete not successful", css="error"))


    return redirect(url_for('admin_page.customer', information="Delete successful", css="success"))



def logged_in():
    if 'username' not in session or 'admin' not in session['userroles']:
        return False
    else:
        return True