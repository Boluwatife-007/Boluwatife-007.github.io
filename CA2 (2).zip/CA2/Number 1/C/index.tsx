import React from 'react';
import { View } from '@/components/Themed';
import { StyleSheet, ScrollView, KeyboardAvoidingView, SafeAreaView, Platform, Image, Text } from 'react-native';
import Biodata from '@/components/core/Biodata';





export const BiodataScreen: React.FC = () => {
  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.container}>
        <ScrollView>
          <View style={styles.screenHeader}>
            <Image style={styles.logo} source={require('../../assets/images/clinteeth.png')} />
            <Text style={styles.logotext}>CLINTEETH</Text>
          </View>
          <Biodata />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF700',
    alignItems: 'center',
    justifyContent: 'center',
  },
  separator: {
    backgroundColor: '#eee',
    height: 3,
    width: '100%',
    margin: 9,
  },
  screenHeader: {
    width: 430,
    height: 130,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    backgroundColor: '#FFF799',
  },
  logo: {
    width: 100,
    height: 99,
    margin: 9,
    alignItems: 'center',
  },
  logotext: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 10,
    marginLeft: 10, // Adds space between logo and text
  },
});

export default BiodataScreen;
